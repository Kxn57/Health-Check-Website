global using Demo.Models;
global using Demo;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using Microsoft.EntityFrameworkCore.Diagnostics;

var builder = WebApplication.CreateBuilder(args);

// Add localization services
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");

builder.Services.AddControllersWithViews()
    .AddViewLocalization()
    .AddDataAnnotationsLocalization();

builder.Services.AddDbContext<DB>(options => options
    .UseSqlServer($@"
        Data Source=(LocalDB)\MSSQLLocalDB;
        AttachDbFilename={builder.Environment.ContentRootPath}\DB.mdf;
    ")
    .ConfigureWarnings(w => w.Ignore(RelationalEventId.PendingModelChangesWarning)));
builder.Services.AddScoped<Helper>();
builder.Services.AddHttpClient();
builder.Services.AddAuthentication().AddCookie();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession();

var app = builder.Build();

// Keep the demo appointment packages in sync with the health check-up UI.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<DB>();
    db.Database.Migrate();
    var packages = new[]
    {
        ("C", "CBC Test",          45.00m),
        ("X", "X-ray Chest",       80.00m),
        ("E", "ECG",               65.00m),
        ("S", "Stress Test",      150.00m),
        ("B", "Height & Weight BMI",30.00m),
        ("K", "Kidney Profile",    85.00m),
        ("L", "Liver Profile",     85.00m),
        ("D", "Vitamin D",         95.00m),
    };

    foreach (var (id, name, price) in packages)
    {
        var type = db.Types.Find(id);
        if (type == null)
        {
            db.Types.Add(new Demo.Models.Type { Id = id, Name = name, Price = price });
        }
        else
        {
            type.Name = name;
            type.Price = price;
        }

        if (!db.Rooms.Any(r => r.TypeId == id))
        {
            db.Rooms.Add(new Room { Id = $"{id}001", TypeId = id });
        }
    }

    db.SaveChanges();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// Configure Supported Cultures (English, Chinese, Malay)
var supportedCultures = new[]
{
    new CultureInfo("en-US"),
    new CultureInfo("zh-CN"),
    new CultureInfo("ms-MY")
};

app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("en-US"),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
});

app.UseSession();
app.MapDefaultControllerRoute();
app.Run();
