﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Demo.Models;

#nullable disable warnings

// View Models ----------------------------------------------------------------

public class LoginVM
{
    [StringLength(100)]
    [EmailAddress]
    public string Email { get; set; }

    [StringLength(100, MinimumLength = 5)]
    [DataType(DataType.Password)]
    public string Password { get; set; }

    public bool RememberMe { get; set; }
}

public class RegisterVM
{
    [StringLength(100)]
    [EmailAddress]
    [Remote("CheckEmail", "Account", ErrorMessage = "Duplicated {0}.")]
    public string Email { get; set; }

    [StringLength(100, MinimumLength = 5)]
    [DataType(DataType.Password)]
    public string Password { get; set; }

    [StringLength(100, MinimumLength = 5)]
    [Compare("Password")]
    [DataType(DataType.Password)]
    [DisplayName("Confirm Password")]
    public string Confirm { get; set; }

    [StringLength(100)]
    public string Name { get; set; }

    [Required, Phone, StringLength(20)]
    [DisplayName("Mobile number")]
    public string Telephone { get; set; }

    [Required, StringLength(6, MinimumLength = 6)]
    [DisplayName("SMS verification code")]
    public string PhoneOtp { get; set; }

    public string Role { get; set; } = "Member"; // Default to Member

    public IFormFile? Photo { get; set; }
}

public class CreateAdminVM
{
    [Required, StringLength(100), EmailAddress]
    public string Email { get; set; } = "";

    [Required, StringLength(100)]
    public string Name { get; set; } = "";

    [Required, StringLength(100, MinimumLength = 5)]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required, StringLength(100, MinimumLength = 5)]
    [Compare("Password")]
    [DataType(DataType.Password)]
    [DisplayName("Confirm Password")]
    public string Confirm { get; set; } = "";

    [Required, StringLength(6, MinimumLength = 6)]
    [DisplayName("Email verification code")]
    public string EmailOtp { get; set; } = "";
}

public class UpdatePasswordVM
{
    [StringLength(100, MinimumLength = 5)]
    [DataType(DataType.Password)]
    [DisplayName("Current Password")]
    public string Current { get; set; }

    [StringLength(100, MinimumLength = 5)]
    [DataType(DataType.Password)]
    [DisplayName("New Password")]
    public string New { get; set; }

    [StringLength(100, MinimumLength = 5)]
    [Compare("New")]
    [DataType(DataType.Password)]
    [DisplayName("Confirm Password")]
    public string Confirm { get; set; }
}

public class UpdateProfileVM
{
    [Required, StringLength(100)]
    public string Name { get; set; } = "";

    public string Email { get; set; } = "";
    public string? PhotoURL { get; set; }

    public IFormFile? Photo { get; set; }

    [Required]
    public DateOnly? DateOfBirth { get; set; }

    [Required, StringLength(1)]
    public string? Gender { get; set; }
}

public class ResetPasswordVM
{
    [StringLength(100)]
    [EmailAddress]
    public string Email { get; set; }
}

public class UpdateEmailVM
{
    [Required(ErrorMessage = "Please enter your new email address.")]
    [EmailAddress(ErrorMessage = "Invalid email format.")]
    [Display(Name = "New Email Address")]
    public string NewEmail { get; set; }
}

// Reservation

public class ReserveVM
{
    [DisplayName("Select Doctor")]
    public int? DoctorId { get; set; }

    [Required]
    [DisplayName("Check Up Type")]
    public string TypeId { get; set; }

    [Required]
    [DisplayName("Check Up Date")]
    [DataType(DataType.Date)]
    public DateOnly CheckIn { get; set; }

    [DataType(DataType.Date)]
    public DateOnly CheckOut { get; set; }

    // Payment Fields
    [Required(ErrorMessage = "Cardholder Name is required")]
    [DisplayName("Cardholder Name")]
    public string CardName { get; set; }

    [Required(ErrorMessage = "Card Number is required")]
    [CreditCard(ErrorMessage = "Invalid credit card number")]
    [DisplayName("Card Number")]
    public string CardNumber { get; set; }

    [Required(ErrorMessage = "Expiry Date is required")]
    [RegularExpression(@"^(0[1-9]|1[0-2])\/?([0-9]{2})$", ErrorMessage = "Format must be MM/YY")]
    [DisplayName("Expiry (MM/YY)")]
    public string Expiry { get; set; }

    [Required(ErrorMessage = "CVV is required")]
    [RegularExpression(@"^[0-9]{3,4}$", ErrorMessage = "CVV must be 3 or 4 digits")]
    public string CVV { get; set; }

    public string PaymentMethod { get; set; } = "QR";
}

public class DoctorVM
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Specialty { get; set; }
    public string Qualifications { get; set; }
    public string ImageName { get; set; }
}

