﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net.Mail;

namespace Demo.Controllers;

public class HomeController(DB db, Helper hp) : Controller
{
    // GET: Home/Index
    public IActionResult Index()
    {
        ViewBag.Members = db.Members;
        ViewBag.Types   = db.Types.OrderBy(t => t.Price);
        ViewBag.Rooms   = db.Rooms.OrderBy(rm => rm.Id);
        return View();
    }

    // ------------------------------------------------------------------------
    // Reservation
    // ------------------------------------------------------------------------

    // Secure Detail view: Ensure users can only view their own reservations
    [Authorize]
    public IActionResult Detail(int id)
    {
        var rs = db.Reservations
                   .Include(r => r.Member)
                   .Include(r => r.Room)
                   .ThenInclude(rm => rm.Type)
                   .FirstOrDefault(r => r.Id == id);

        if (rs == null) return RedirectToAction("Index");

        // Member access restriction check
        if (User.IsInRole("Member") && rs.MemberEmail != User.Identity!.Name)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        return View(rs);
    }

    // GET: Home/Reserve
    [Authorize(Roles = "Member")]
    public IActionResult Reserve()
    {
        var m = db.Members.Find(User.Identity!.Name)!;
        if (m.DateOfBirth == null || m.Gender == null)
        {
            TempData["Info"] = "Please complete your date of birth and gender before booking, so we can show you the correct price.";
            return RedirectToAction("UpdateProfile", "Account");
        }

        var vm = new ReserveVM
        {
            CheckIn = DateTime.Today.ToDateOnly(),
            CheckOut = DateTime.Today.ToDateOnly().AddDays(1),
        };

        ViewBag.TypeList = new SelectList(db.Types.OrderBy(t => t.Price), "Id", "Name");
        return View(vm);
    }

    // POST: Home/Reserve
    [Authorize(Roles = "Member")]
    [HttpPost]
    public IActionResult Reserve(ReserveVM vm)
    {
        // QR payments do not collect card details. Remove validation errors for
        // fields that are deliberately hidden in the QR payment form.
        if (vm.PaymentMethod == "QR")
        {
            ModelState.Remove(nameof(ReserveVM.CardName));
            ModelState.Remove(nameof(ReserveVM.CardNumber));
            ModelState.Remove(nameof(ReserveVM.Expiry));
            ModelState.Remove(nameof(ReserveVM.CVV));
        }

        // A health check-up is a one-day appointment. CheckOut is kept as a
        // hidden technical field, so calculate it from the date the member
        // selected instead of accepting a stale hidden value from the form.
        vm.CheckOut = vm.CheckIn.AddDays(1);

        // Date Range Validations
        if (ModelState.IsValid("CheckIn"))
        {
            var a = DateTime.Today.ToDateOnly();
            var b = DateTime.Today.ToDateOnly().AddDays(30);
            if (vm.CheckIn < a || vm.CheckIn > b)
            {
                ModelState.AddModelError("CheckIn", "Date out of range.");
            }
        }

        if (ModelState.IsValid)
        {
            var occupied = db.Reservations
                                .Where(rs => vm.CheckIn < rs.CheckOut && rs.CheckIn < vm.CheckOut)
                                .Select(rs => rs.Room);

            Room? room = db.Rooms
                            .Except(occupied)
                            .Include(rm => rm.Type)
                            .FirstOrDefault(rm => rm.TypeId == vm.TypeId);

            if (room == null)
            {
                ModelState.AddModelError("TypeId", "No room available.");
            }
            else
            {
                var member = db.Members.Find(User.Identity!.Name)!;
                var rs = new Reservation
                {
                    MemberEmail = member.Email,
                    RoomId = room.Id,
                    CheckIn = vm.CheckIn,
                    CheckOut = vm.CheckOut,
                    Price = GetPrice(vm.TypeId, member),
                    Paid = true // Processed & paid automatically via gateway form
                };

                db.Reservations.Add(rs);
                db.SaveChanges();

                // Reload navigation properties (Member, Room, Room.Type) so the
                // confirmation email/receipt has everything it needs to render.
                rs.Member = member;
                rs.Room = room;
                SendBookingConfirmationEmail(rs, "New Booking Confirmed");
                hp.SendSms(member.Telephone, $"CarePoint: booking #{rs.Id} for {rs.Room.Type.Name} on {rs.CheckIn:yyyy-MM-dd} is confirmed.");

                TempData["Info"] = "Payment successful! Room reserved. A confirmation email with your e-receipt has been sent.";
                TempData["ShowPaymentReceipt"] = true;
                return RedirectToAction("Detail", new { rs.Id });
            }
        }

        ViewBag.TypeList = new SelectList(db.Types.OrderBy(t => t.Price), "Id", "Name");
        return View(vm);
    }

    // GET: Home/List
    [Authorize(Roles = "Admin")]
    public IActionResult List()
    {
        var m = db.Reservations
                  .Include(rs => rs.Member)
                  .Include(rs => rs.Room)
                  .ThenInclude(rm => rm.Type);

        return View(m);
    }

    // GET: Home/Detail
    public IActionResult Details(int id)
    {
        var rs = db.Reservations
                   .Include(r => r.Member)
                   .Include(r => r.Room)
                   .ThenInclude(rm => rm.Type)
                   .FirstOrDefault(r => r.Id == id);

        if (rs == null)
        {
            return RedirectToAction("Index");
        }

        return View(rs);
    }

    // POST: Home/Reset
    [HttpPost]
    public IActionResult Reset()
    {
        db.Database.ExecuteSqlRaw(@"
            TRUNCATE TABLE [Reservations];
        ");

        return RedirectToAction("List");
    }

    // GET: Home/MyAppointments
    [Authorize(Roles = "Member")]
    public IActionResult MyAppointments()
    {
        var email = User.Identity!.Name!;

        var m = db.Reservations
                  .Include(rs => rs.Room)
                  .ThenInclude(rm => rm.Type)
                  .Where(rs => rs.MemberEmail == email)
                  .OrderByDescending(rs => rs.CheckIn);

        return View(m);
    }

    // GET: Home/EditAppointment
    [Authorize(Roles = "Member")]
    public IActionResult EditAppointment(int id)
    {
        var rs = db.Reservations
                   .Include(r => r.Room)
                   .FirstOrDefault(r => r.Id == id && r.MemberEmail == User.Identity!.Name);

        if (rs == null) return RedirectToAction("MyAppointments");

        var vm = new ReserveVM
        {
            TypeId = rs.Room.TypeId,
            CheckIn = rs.CheckIn,
            CheckOut = rs.CheckOut,
        };

        ViewBag.TypeList = new SelectList(db.Types.OrderBy(t => t.Price), "Id", "Name");
        return View(vm);
    }

    // Looks up the correct price for a check-up type based on the
    // member's age (from DateOfBirth) and gender. Falls back to the
    // type's base Price if no matching tier is configured.
    private decimal GetPrice(string typeId, Member m)
    {
        var today = DateTime.Today.ToDateOnly();
        var age = today.Year - m.DateOfBirth!.Value.Year;
        if (m.DateOfBirth.Value.AddYears(age) > today) age--;

        var tier = db.TypePricings
                      .Where(p => p.TypeId == typeId &&
                                  age >= p.MinAge && age <= p.MaxAge &&
                                  (p.Gender == m.Gender || p.Gender == "A"))
                      .OrderBy(p => p.Gender == "A" ? 1 : 0) // prefer exact gender match over "Any"
                      .FirstOrDefault();

        return tier?.Price ?? db.Types.Find(typeId)!.Price;
    }

    // Builds and sends a booking confirmation email containing an HTML e-receipt.
    // Used both when a new reservation is created and when an existing one is edited.
    // Any email failure is swallowed so it never blocks the booking itself
    // (the payment/DB write has already succeeded by the time this runs).
    private void SendBookingConfirmationEmail(Reservation rs, string subjectPrefix)
    {
        try
        {
            var days = Math.Max(1, rs.CheckOut.DayNumber - rs.CheckIn.DayNumber);
            var total = rs.Price * days;

            var mail = new MailMessage();
            mail.To.Add(new MailAddress(rs.Member.Email, rs.Member.Name));
            mail.Subject = $"{subjectPrefix} - Booking #{rs.Id} | CarePoint Medical Center";
            mail.IsBodyHtml = true;

            var detailUrl = Url.Action("Detail", "Home", new { id = rs.Id }, "https");

            mail.Body = $@"
                <div style='font-family: Arial, sans-serif; color: #173a55; max-width: 600px; margin: auto;'>
                    <h2 style='color: #176c96;'>CarePoint Medical Center</h2>
                    <p>Dear {rs.Member.Name},</p>
                    <p>{subjectPrefix.ToLower()}. Here is your official e-receipt:</p>

                    <table style='width: 100%; border-collapse: collapse; margin: 20px 0;'>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Booking ID</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>#{rs.Id}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Check-up Package</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.Room.Type.Name}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Room</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.Room.Id}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Check-in</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.CheckIn:yyyy-MM-dd}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Check-out</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.CheckOut:yyyy-MM-dd}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Days</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>{days}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Price / Day</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'>RM {rs.Price:N2}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Total Paid</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>RM {total:N2}</strong></td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Payment Status</strong></td>
                            <td style='padding: 8px; border: 1px solid #d4e7f0; color: {(rs.Paid ? "green" : "red")};'>
                                {(rs.Paid ? "PAID" : "PENDING")}
                            </td>
                        </tr>
                    </table>

                    <p>You can view or manage this appointment anytime here: <a href='{detailUrl}'>View Booking</a></p>

                    <p style='margin-top: 30px; font-size: 0.85rem; color: #688294;'>
                        This is an automated receipt. Please keep it for your records.<br>
                        From, CarePoint Medical Center
                    </p>
                </div>
            ";

            hp.SendEmail(mail);
        }
        catch
        {
            // Booking already succeeded; a failed confirmation email should not
            // surface as an error to the member. Consider logging this via
            // ILogger in a production setup.
        }
    }

    // POST: Home/EditAppointment
    [Authorize(Roles = "Member")]
    [HttpPost]
    public IActionResult EditAppointment(int id, ReserveVM vm)
    {
        var rs = db.Reservations
                   .FirstOrDefault(r => r.Id == id && r.MemberEmail == User.Identity!.Name);

        if (rs == null) return RedirectToAction("MyAppointments");

        if (vm.PaymentMethod == "QR")
        {
            ModelState.Remove("CardName");
            ModelState.Remove("CardNumber");
            ModelState.Remove("Expiry");
            ModelState.Remove("CVV");
        }

        // Validation: CheckIn within 30 days range
        if (ModelState.IsValid("CheckIn"))
        {
            var a = DateTime.Today.ToDateOnly();
            var b = DateTime.Today.ToDateOnly().AddDays(30);

            if (vm.CheckIn < a || vm.CheckIn > b)
            {
                ModelState.AddModelError("CheckIn", "Date out of range.");
            }
        }

        if (ModelState.IsValid)
        {
            // Find an available room of the requested type,
            // excluding this reservation's own current room slot
            var occupied = db.Reservations
                              .Where(r => r.Id != id &&
                                          vm.CheckIn < r.CheckOut &&
                                          r.CheckIn < vm.CheckOut)
                              .Select(r => r.Room);

            Room? room = db.Rooms
                            .Except(occupied)
                            .Include(r => r.Type)
                            .FirstOrDefault(r => r.TypeId == vm.TypeId);

            if (room == null)
            {
                ModelState.AddModelError("TypeId", "No room available.");
            }
            else
            {
                var member = db.Members.Find(User.Identity!.Name)!;
                rs.RoomId = room.Id;
                rs.CheckIn = vm.CheckIn;
                rs.CheckOut = vm.CheckOut;
                rs.Price = GetPrice(vm.TypeId, member);
                db.SaveChanges();

                // Reload navigation properties for the receipt email
                rs.Member = member;
                rs.Room = room;
                SendBookingConfirmationEmail(rs, "Booking Updated");

                TempData["Info"] = "Appointment updated. An updated e-receipt has been emailed to you.";
                return RedirectToAction("Detail", new { rs.Id });
            }
        }

        ViewBag.TypeList = new SelectList(db.Types.OrderBy(t => t.Price), "Id", "Name");
        return View(vm);
    }

    // POST: Home/DeleteAppointment
    [Authorize(Roles = "Member")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteAppointment(int id)
    {
        var rs = db.Reservations
                   .Include(r => r.Member)
                   .Include(r => r.Room)
                   .ThenInclude(r => r.Type)
                   .FirstOrDefault(r => r.Id == id && r.MemberEmail == User.Identity!.Name);

        if (rs != null)
        {
            db.Reservations.Remove(rs);
            db.SaveChanges();
            SendCancellationEmail(rs, "cancelled as requested");
            TempData["Info"] = "Appointment cancelled. A cancellation notice has been sent to your email.";
        }

        return RedirectToAction("MyAppointments");
    }

    // Sends a receipt-style record after a customer cancels an appointment.
    // The reservation is intentionally deleted first; notification failure
    // must never prevent a cancellation that has already succeeded.
    [Authorize(Roles = "Admin")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult AdminCancelAppointment(int id)
    {
        var rs = db.Reservations
                   .Include(r => r.Member)
                   .Include(r => r.Room)
                   .ThenInclude(r => r.Type)
                   .FirstOrDefault(r => r.Id == id);

        if (rs == null) return RedirectToAction("List");

        db.Reservations.Remove(rs);
        db.SaveChanges();
        SendCancellationEmail(rs, "cancelled by the CarePoint care team");
        TempData["Info"] = "Appointment cancelled. The customer has been emailed a cancellation notice.";
        return RedirectToAction("List");
    }

    private void SendCancellationEmail(Reservation rs, string cancellationMessage)
    {
        try
        {
            var mail = new MailMessage();
            mail.To.Add(new MailAddress(rs.Member.Email, rs.Member.Name));
            mail.Subject = $"Appointment Cancelled - Booking #{rs.Id} | CarePoint Medical Center";
            mail.IsBodyHtml = true;
            mail.Body = $@"
                <div style='font-family: Arial, sans-serif; color: #173a55; max-width: 600px; margin: auto;'>
                    <h2 style='color: #176c96;'>CarePoint Medical Center</h2>
                    <p>Dear {rs.Member.Name},</p>
                    <p>Your appointment has been {cancellationMessage}. This email is your cancellation record.</p>
                    <table style='width: 100%; border-collapse: collapse; margin: 20px 0;'>
                        <tr><td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Booking ID</strong></td><td style='padding: 8px; border: 1px solid #d4e7f0;'>#{rs.Id}</td></tr>
                        <tr><td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Check-up Package</strong></td><td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.Room.Type.Name}</td></tr>
                        <tr><td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Appointment Date</strong></td><td style='padding: 8px; border: 1px solid #d4e7f0;'>{rs.CheckIn:yyyy-MM-dd}</td></tr>
                        <tr><td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Payment Status</strong></td><td style='padding: 8px; border: 1px solid #d4e7f0;'>{(rs.Paid ? "Paid" : "Not paid")}</td></tr>
                        <tr><td style='padding: 8px; border: 1px solid #d4e7f0;'><strong>Cancellation Status</strong></td><td style='padding: 8px; border: 1px solid #d4e7f0; color: #b42318;'><strong>CANCELLED</strong></td></tr>
                    </table>
                    <p>If you need a new appointment, you can book another health check-up through CarePoint.</p>
                </div>";
            hp.SendEmail(mail);
        }
        catch
        {
            // The appointment cancellation remains successful even when email
            // delivery is temporarily unavailable.
        }
    }

    // GET: Home/Status
    public IActionResult Status(DateOnly? month, int week = 0)
    {
        var m = month.GetValueOrDefault(DateTime.Today.ToDateOnly());

        // Min = First day of the month
        // Max = First day of next month

        var min = new DateOnly(m.Year, m.Month, 1);
        var max = min.AddMonths(1);
        ViewBag.Min = min;
        ViewBag.Max = max;

        // Paginate the month into 7-day (one week) pages.
        // Each page always shows a full 7 days, even if it spills
        // into the previous/next month.
        var totalDays = max.DayNumber - min.DayNumber;
        var totalWeeks = (int)Math.Ceiling(totalDays / 7.0);
        week = Math.Clamp(week, 0, totalWeeks - 1);

        var weekStart = min.AddDays(week * 7);
        var weekEnd = weekStart.AddDays(7);

        ViewBag.Week = week;
        ViewBag.TotalWeeks = totalWeeks;
        ViewBag.WeekStart = weekStart;
        ViewBag.WeekEnd = weekEnd;

        // 1. Initialize dictionary
        // ------------------------
        // Dictionary<Room, List<DateOnly>>
        // Key   = Room object
        // Value = List of DateOnly objects
        //
        // dict[R001] = [2022-12-01, 2022-12-02, ...]
        // dict[R002] = [2022-12-03, 2022-12-04, ...]

        var dict = db.Rooms
                     .Include(rm => rm.Type)
                     .OrderBy(rm => rm.Id)
                     .ToDictionary(rm => rm, rm => new List<DateOnly>());

        // 2. Retrieve reservation records
        // -------------------------------
        // Query against the displayed week range (not just the month),
        // since the week may spill into an adjacent month.

        var reservations = db.Reservations
                             .Include(rs => rs.Room)
                             .ThenInclude(room => room.Type)
                             .Where(rs => weekStart < rs.CheckOut && rs.CheckIn < weekEnd)
                             .ToList();

        // The public status board intentionally exposes appointment information,
        // not patient identity. The view uses these short descriptions as hover
        // tooltips for occupied cells.
        var details = new Dictionary<string, string>();

        // 3. Fill the dictionary
        // ----------------------
        // Example: CheckIn = 2024-12-10, CheckOut = 2024-12-15
        // Entries --> 10, 11, 12, 13, 14 *** 15 not included ***

        foreach (var rs in reservations)
        {
            for (var d = rs.CheckIn; d < rs.CheckOut; d = d.AddDays(1))
            {
                if (d >= weekStart && d < weekEnd)
                {
                    dict[rs.Room].Add(d);
                    details[$"{rs.RoomId}|{d:yyyy-MM-dd}"] = $"Booked · {rs.Room.Type.Name} · {d:dd MMM}";
                }
            }
        }
        ViewBag.BookingDetails = details;
        return View(dict);
    }

    // Helper to get simulated doctor records
    private List<DoctorVM> GetDoctors()
    {
        return new List<DoctorVM>
    {
        new DoctorVM
        {
            Id = 1,
            Name = "Dr. Robert Chen",
            Specialty = "Cardiology & Preventive Medicine",
            Qualifications = "MBBS (Malaya), FRCP (UK)",
            ImageName = "doctor1.jpg"
        },
        new DoctorVM
        {
            Id = 2,
            Name = "Dr. Sarah Lee",
            Specialty = "Internal Medicine & Wellness",
            Qualifications = "MD (UKM), MMed (Int Med)",
            ImageName = "doctor2.jpg"
        }
    };
    }

    // GET: Home/Doctors
    public IActionResult Doctors()
    {
        var list = GetDoctors();
        return View(list);
    }

    [HttpPost]
    public IActionResult SetLanguage(string culture, string returnUrl)
    {
        Response.Cookies.Append(
            CookieRequestCultureProvider.DefaultCookieName,
            CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
            new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1) }
        );

        return LocalRedirect(returnUrl);
    }


}
