﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;

namespace Demo.Controllers;

public class AccountController(DB db, 
                               IWebHostEnvironment en, 
                               Helper hp) : Controller
{
    // GET: Account/Login
    public IActionResult Login()
    {
        ViewBag.RecaptchaSiteKey = hp.RecaptchaSiteKey;
        return View();
    }

    // POST: Account/Login
    [HttpPost]
    public IActionResult Login(LoginVM vm, string? returnURL)
    {
        ViewBag.RecaptchaSiteKey = hp.RecaptchaSiteKey;
        var u = db.Users.Find(vm.Email);

        if (u?.LockoutUntilUtc > DateTime.UtcNow)
        {
            var remaining = (int)Math.Ceiling((u.LockoutUntilUtc.Value - DateTime.UtcNow).TotalMinutes);
            ModelState.AddModelError("", $"This account is temporarily locked. Try again in {remaining} minute(s).");
        }
        else if (!hp.VerifyRecaptcha(Request.Form["g-recaptcha-response"]))
        {
            ModelState.AddModelError("", "Please complete the CAPTCHA verification.");
        }
        else if (u == null || !hp.VerifyPassword(u.Hash, vm.Password))
        {
            if (u != null)
            {
                u.FailedLoginAttempts++;
                if (u.FailedLoginAttempts >= 3)
                {
                    u.FailedLoginAttempts = 0;
                    u.LockoutUntilUtc = DateTime.UtcNow.AddMinutes(15);
                    ModelState.AddModelError("", "Too many failed attempts. Your account is locked for 15 minutes.");
                }
                else
                {
                    ModelState.AddModelError("", $"Login credentials not matched. {3 - u.FailedLoginAttempts} attempt(s) remaining.");
                }
                db.SaveChanges();
            }
            else ModelState.AddModelError("", "Login credentials not matched.");
        }
        else if (ModelState.IsValid)
        {
            u.FailedLoginAttempts = 0;
            u.LockoutUntilUtc = null;
            db.SaveChanges();
            TempData["Info"] = "Login successfully.";

            hp.SignIn(u!.Email, u.Role, vm.RememberMe);
            
            if (!string.IsNullOrWhiteSpace(returnURL) && Url.IsLocalUrl(returnURL))
            {
                return LocalRedirect(returnURL);
            }

            return RedirectToAction("Index", "Home");
        }
        
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult SendPhoneOtp(string telephone)
    {
        telephone = hp.NormalizeTelephone(telephone);
        if (!System.Text.RegularExpressions.Regex.IsMatch(telephone, @"^\+[1-9]\d{7,14}$"))
            return BadRequest(new { message = "Enter a mobile number with country code, for example +60126680598." });

        var code = Random.Shared.Next(100000, 1000000).ToString();
        HttpContext.Session.SetString("phone-otp:number", telephone);
        HttpContext.Session.SetString("phone-otp:code", code);
        HttpContext.Session.SetString("phone-otp:expires", DateTime.UtcNow.AddMinutes(10).Ticks.ToString());
        var sent = hp.SendSms(telephone, $"Your CarePoint verification code is {code}. It expires in 10 minutes.");
        if (!sent)
            return StatusCode(502, new { message = "SMS could not be sent. Check your Twilio number, credentials, and verified recipient number." });

        return Json(new { message = "Verification code sent. It expires in 10 minutes.", demoCode = hp.IsRealSmsEnabled ? (string?)null : code });
    }

    // GET: Account/Logout
    public IActionResult Logout(string? returnURL)
    {
        TempData["Info"] = "Logout successfully.";

        hp.SignOut();

        return RedirectToAction("Index", "Home");
    }

    // GET: Account/AccessDenied
    public IActionResult AccessDenied(string? returnURL)
    {
        return View();
    }



    // ------------------------------------------------------------------------
    // Others
    // ------------------------------------------------------------------------

    [Authorize]
    public IActionResult UpdateEmail()
    {
        return View();
    }

    [Authorize]
    [HttpPost]  
    public async Task<IActionResult> UpdateEmail(UpdateEmailVM vm)
    {
        if (ModelState.IsValid)
        {
            // Find the current logged-in user
            var member = db.Members.Find(User.Identity.Name);

            if (member == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Check if the new email is already registered to someone else
            bool emailExists = db.Members.Any(m => m.Email == vm.NewEmail);
            if (emailExists)
            {
                ModelState.AddModelError("NewEmail", "This email is already in use.");
                return View(vm);
            }

            // Update the email
            member.Email = vm.NewEmail;

            db.SaveChanges();

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            TempData["Info"] = "Email updated successfully. Please log in with your new email.";

            return RedirectToAction("Login", "Account");
        }

        return View(vm);
    }


    // GET: Account/CheckEmail
    public bool CheckEmail(string email)
    {
        return !db.Users.Any(u => u.Email == email);
    }

    // GET: Account/Register
    public IActionResult Register()
    {
        ViewBag.RecaptchaSiteKey = hp.RecaptchaSiteKey;
        return View();
    }

    // POST: Account/Register
    [HttpPost]
    public IActionResult Register(RegisterVM vm)
    {
        ViewBag.RecaptchaSiteKey = hp.RecaptchaSiteKey;
        vm.Telephone = hp.NormalizeTelephone(vm.Telephone);

        if (!hp.VerifyRecaptcha(Request.Form["g-recaptcha-response"]))
        {
            ModelState.AddModelError("", "Please complete the CAPTCHA verification.");
        }

        if (ModelState.IsValid("Email") &&
            db.Users.Any(u => u.Email == vm.Email))
        {
            ModelState.AddModelError("Email", "Duplicated Email.");
        }

        if (!IsPhoneOtpValid(vm.Telephone, vm.PhoneOtp))
            ModelState.AddModelError("PhoneOtp", "Enter the current verification code sent to your mobile number.");

        if (vm.Photo is not null && ModelState.IsValid("Photo"))
        {
            var err = hp.ValidatePhoto(vm.Photo);
            if (err != "") ModelState.AddModelError("Photo", err);
        }

        if (ModelState.IsValid)
        {
            // Check if registering as Admin or Member
            if (vm.Role == "Admin")
            {
                db.Admins.Add(new Admin()
                {
                    Email = vm.Email,
                    Hash = hp.HashPassword(vm.Password),
                    Name = vm.Name,
                });
            }
            else
            {
                db.Members.Add(new Member()
                {
                    Email = vm.Email,
                    Hash = hp.HashPassword(vm.Password),
                    Name = vm.Name,
                    Telephone = vm.Telephone,
                    TelephoneVerified = true,
                    // A profile photo is optional on the registration form. Keep the
                    // bundled placeholder when no file was posted rather than trying
                    // to open a stream on a null IFormFile.
                    PhotoURL = vm.Photo is null
                        ? "photo.jpg"
                        : hp.SavePhoto(vm.Photo, "photos"),
                });
            }

            db.SaveChanges();
            HttpContext.Session.Remove("phone-otp:number");
            HttpContext.Session.Remove("phone-otp:code");
            HttpContext.Session.Remove("phone-otp:expires");

            TempData["Info"] = "Register successfully. Please login.";
            return RedirectToAction("Login");
        }

        return View(vm);
    }

    private bool IsPhoneOtpValid(string? telephone, string? code)
    {
        if (string.IsNullOrWhiteSpace(telephone) || string.IsNullOrWhiteSpace(code)) return false;
        if (!long.TryParse(HttpContext.Session.GetString("phone-otp:expires"), out var ticks) || DateTime.UtcNow > new DateTime(ticks, DateTimeKind.Utc)) return false;
        return telephone == HttpContext.Session.GetString("phone-otp:number")
               && code == HttpContext.Session.GetString("phone-otp:code");
    }

    // GET: Account/CreateAdmin
    [Authorize(Roles = "Admin")]
    public IActionResult CreateAdmin()
    {
        return View();
    }

    [Authorize(Roles = "Admin")]
    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult SendAdminEmailOtp(string email)
    {
        email = (email ?? "").Trim().ToLowerInvariant();
        if (!new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email))
            return BadRequest(new { message = "Enter a valid admin email address first." });

        var code = Random.Shared.Next(100000, 1000000).ToString();
        try
        {
            var mail = new MailMessage();
            mail.To.Add(email);
            mail.Subject = "CarePoint Admin Verification Code";
            mail.IsBodyHtml = true;
            mail.Body = $"<p>Your CarePoint administrator verification code is:</p><h2 style='letter-spacing:4px'>{code}</h2><p>This code expires in 10 minutes. Do not share it.</p>";
            hp.SendEmail(mail);
        }
        catch
        {
            return StatusCode(502, new { message = "The verification email could not be sent. Check the Gmail SMTP settings and try again." });
        }

        HttpContext.Session.SetString("admin-email-otp:email", email);
        HttpContext.Session.SetString("admin-email-otp:code", code);
        HttpContext.Session.SetString("admin-email-otp:expires", DateTime.UtcNow.AddMinutes(10).Ticks.ToString());
        return Json(new { message = "Verification code sent to the admin email. It expires in 10 minutes." });
    }

    // POST: Account/CreateAdmin
    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult CreateAdmin(CreateAdminVM vm)
    {
        vm.Email = (vm.Email ?? "").Trim().ToLowerInvariant();
        if (ModelState.IsValid("Email") && db.Users.Any(u => u.Email == vm.Email))
        {
            ModelState.AddModelError("Email", "Duplicated Email.");
        }

        if (!IsAdminEmailOtpValid(vm.Email, vm.EmailOtp))
        {
            ModelState.AddModelError("EmailOtp", "Enter the current verification code sent to this email address.");
        }

        if (ModelState.IsValid)
        {
            db.Admins.Add(new Admin
            {
                Email = vm.Email,
                Hash = hp.HashPassword(vm.Password),
                Name = vm.Name,
            });

            db.SaveChanges();
            HttpContext.Session.Remove("admin-email-otp:email");
            HttpContext.Session.Remove("admin-email-otp:code");
            HttpContext.Session.Remove("admin-email-otp:expires");

            var welcomeSent = SendAdminWelcomeEmail(vm.Email, vm.Name);
            TempData["Info"] = welcomeSent
                ? "Admin account created. Login information has been emailed to the new admin."
                : "Admin account created, but the welcome email could not be sent.";
            return RedirectToAction(nameof(AdminList));
        }

        return View(vm);
    }

    private bool IsAdminEmailOtpValid(string? email, string? code)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(code)) return false;
        if (!long.TryParse(HttpContext.Session.GetString("admin-email-otp:expires"), out var ticks) || DateTime.UtcNow > new DateTime(ticks, DateTimeKind.Utc)) return false;
        return email == HttpContext.Session.GetString("admin-email-otp:email")
               && code == HttpContext.Session.GetString("admin-email-otp:code");
    }

    private bool SendAdminWelcomeEmail(string email, string name)
    {
        try
        {
            var mail = new MailMessage();
            mail.To.Add(new MailAddress(email, name));
            mail.Subject = "Your CarePoint Administrator Account";
            mail.IsBodyHtml = true;
            var loginUrl = Url.Action("Login", "Account", null, "https");
            mail.Body = $@"
                <div style='font-family:Arial,sans-serif;color:#173a55;max-width:600px;margin:auto'>
                    <h2 style='color:#176c96'>Welcome to CarePoint</h2>
                    <p>Dear {name},</p>
                    <p>Your CarePoint administrator account has been created.</p>
                    <table style='border-collapse:collapse'>
                        <tr><td style='padding:8px;border:1px solid #d4e7f0'><strong>Administrator email</strong></td><td style='padding:8px;border:1px solid #d4e7f0'>{email}</td></tr>
                        <tr><td style='padding:8px;border:1px solid #d4e7f0'><strong>Role</strong></td><td style='padding:8px;border:1px solid #d4e7f0'>CarePoint Administrator</td></tr>
                    </table>
                    <p>Use the password created for you by the care team. For security, passwords are never sent by email.</p>
                    <p><a href='{loginUrl}'>Log in to CarePoint</a></p>
                </div>";
            hp.SendEmail(mail);
            return true;
        }
        catch
        {
            return false;
        }
    }

    [Authorize(Roles = "Admin")]
    public IActionResult AdminList()
    {
        return View(db.Admins.OrderBy(a => a.Name).ToList());
    }

    // GET: Account/UpdatePassword
    [Authorize]
    public IActionResult UpdatePassword()
    {
        return View();
    }

    // POST: Account/UpdatePassword
    [Authorize]
    [HttpPost]
    public IActionResult UpdatePassword(UpdatePasswordVM vm)
    {
        var u = db.Users.Find(User.Identity!.Name);
        if (u == null) return RedirectToAction("Index", "Home");

        if (!hp.VerifyPassword(u.Hash, vm.Current))
        {
            ModelState.AddModelError("Current", "Current Password not matched.");
        }

        if (ModelState.IsValid)
        {
            u.Hash = hp.HashPassword(vm.New);
            db.SaveChanges();

            TempData["Info"] = "Password updated.";
            return RedirectToAction();
        }

        return View();
    }

    // GET: Account/Profile
    [Authorize(Roles = "Member")]
    public IActionResult Profile()
    {
        var m = db.Members.Find(User.Identity!.Name);
        if (m == null) return RedirectToAction("Index", "Home");

        return View(m);
    }

    // GET: Account/UpdateProfile
    [Authorize(Roles = "Member")]
    public IActionResult UpdateProfile()
    {
        var m = db.Members.Find(User.Identity!.Name);
        if (m == null) return RedirectToAction("Index", "Home");

        var vm = new UpdateProfileVM
        {
            Email = m.Email,
            Name = m.Name,
            PhotoURL = m.PhotoURL,
            DateOfBirth = m.DateOfBirth,
            Gender = m.Gender
        };

        return View(vm);
    }

    // POST: Account/UpdateProfile
    [Authorize(Roles = "Member")]
    [HttpPost]
    public IActionResult UpdateProfile(UpdateProfileVM vm)
    {
        var m = db.Members.Find(User.Identity!.Name);
        if (m == null) return RedirectToAction("Index", "Home");

        if (vm.Photo != null)
        {
            var err = hp.ValidatePhoto(vm.Photo);
            if (err != "") ModelState.AddModelError("Photo", err);
        }

        if (ModelState.IsValid)
        {
            m.Name = vm.Name;
            m.DateOfBirth = vm.DateOfBirth;
            m.Gender = vm.Gender;

            if (vm.Photo != null)
            {
                hp.DeletePhoto(m.PhotoURL, "photos");
                m.PhotoURL = hp.SavePhoto(vm.Photo, "photos");
            }

            db.SaveChanges();

            TempData["Info"] = "Profile updated.";
            return RedirectToAction("Profile"); // <-- Redirect explicitly to Profile
        }

        vm.Email = m.Email;
        vm.PhotoURL = m.PhotoURL;

        return View(vm);
    }

    // GET: Account/ResetPassword
    public IActionResult ResetPassword()
    {
        return View();
    }

    // POST: Account/ResetPassword
    [HttpPost]
    public IActionResult ResetPassword(ResetPasswordVM vm)
    {
        var u = db.Users.Find(vm.Email);

        if (u == null)
        {
            ModelState.AddModelError("Email", "Email not found.");
        }

        if (ModelState.IsValid)
        {
            string password = hp.RandomPassword();

            u!.Hash = hp.HashPassword(password);
            db.SaveChanges();

            // Send reset password email
            SendResetPasswordEmail(u, password);

            TempData["Info"] = $"Password reset. Check your email.";
            return RedirectToAction();
        }

        return View();
    }

    private void SendResetPasswordEmail(User u, string password)
    {
        var mail = new MailMessage();
        mail.To.Add(new MailAddress(u.Email, u.Name));
        mail.Subject = "Reset Password";
        mail.IsBodyHtml = true;

        var url = Url.Action("Login", "Account", null, "https");

        var path = u switch
        {
            Admin    => Path.Combine(en.WebRootPath, "photos", "admin.jpg"),
            Member m => Path.Combine(en.WebRootPath, "photos", m.PhotoURL),
            _        => "",
        };

        var att = new Attachment(path);
        mail.Attachments.Add(att);
        att.ContentId = "photo";

        mail.Body = $@"
            <img src='cid:photo' style='width: 200px; height: 200px;
                                        border: 1px solid #333'>
            <p>Dear {u.Name},<p>
            <p>Your password has been reset to:</p>
            <h1 style='color: red'>{password}</h1>
            <p>
                Please <a href='{url}'>login</a>
                with your new password.
            </p>
            <p>From, 🐱 Super Admin</p>
        ";

        hp.SendEmail(mail);
    }
}
