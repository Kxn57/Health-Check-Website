using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Demo.Migrations;

[DbContext(typeof(DB))]
[Migration("20260906010000_AddAccountSecurityAndTelephone")]
public partial class AddAccountSecurityAndTelephone : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<int>(name: "FailedLoginAttempts", table: "Users", type: "int", nullable: false, defaultValue: 0);
        migrationBuilder.AddColumn<DateTime>(name: "LockoutUntilUtc", table: "Users", type: "datetime2", nullable: true);
        migrationBuilder.AddColumn<string>(name: "Telephone", table: "Users", type: "nvarchar(20)", maxLength: 20, nullable: true);
        migrationBuilder.AddColumn<bool>(name: "TelephoneVerified", table: "Users", type: "bit", nullable: false, defaultValue: false);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(name: "FailedLoginAttempts", table: "Users");
        migrationBuilder.DropColumn(name: "LockoutUntilUtc", table: "Users");
        migrationBuilder.DropColumn(name: "Telephone", table: "Users");
        migrationBuilder.DropColumn(name: "TelephoneVerified", table: "Users");
    }
}
