﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System.Net.Mail;
using System.Net;
using System.Security.Claims;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Demo;

public class Helper(IWebHostEnvironment en,
                    IHttpContextAccessor ct,
                    IConfiguration cf,
                    IHttpClientFactory hf)
{
    // ------------------------------------------------------------------------
    // Photo Upload Helper Functions
    // ------------------------------------------------------------------------

    public string ValidatePhoto(IFormFile f)
    {
        var reType = new Regex(@"^image\/(jpeg|png)$", RegexOptions.IgnoreCase);
        var reName = new Regex(@"^.+\.(jpeg|jpg|png)$", RegexOptions.IgnoreCase);

        if (!reType.IsMatch(f.ContentType) || !reName.IsMatch(f.FileName))
        {
            return "Only JPG and PNG photo is allowed.";
        }
        else if (f.Length > 1 * 1024 * 1024)
        {
            return "Photo size cannot more than 1MB.";
        }

        return "";
    }

    public string SavePhoto(IFormFile f, string folder)
    {
        var file = Guid.NewGuid().ToString("n") + ".jpg";
        var path = Path.Combine(en.WebRootPath, folder, file);

        var options = new ResizeOptions
        {
            Size = new(200, 200),
            Mode = ResizeMode.Crop,
        };

        using var stream = f.OpenReadStream();
        using var img = Image.Load(stream);
        img.Mutate(x => x.Resize(options));
        img.Save(path);

        return file;
    }

    public void DeletePhoto(string file, string folder)
    {
        file = Path.GetFileName(file);
        var path = Path.Combine(en.WebRootPath, folder, file);
        File.Delete(path);
    }



    // ------------------------------------------------------------------------
    // Security Helper Functions
    // ------------------------------------------------------------------------

    private readonly PasswordHasher<object> ph = new();

    public string HashPassword(string password)
    {
        return ph.HashPassword(0, password);
    }

    public bool VerifyPassword(string hash, string password)
    {
        return ph.VerifyHashedPassword(0, hash, password)
               == PasswordVerificationResult.Success;
    }

    public void SignIn(string email, string role, bool rememberMe)
    {
        List<Claim> claims =
        [
            new(ClaimTypes.Name, email),
            new(ClaimTypes.Role, role),
        ];

        ClaimsIdentity identity = new(claims, "Cookies");

        ClaimsPrincipal principal = new(identity);

        AuthenticationProperties properties = new()
        {
            IsPersistent = rememberMe,
        };

        ct.HttpContext!.SignInAsync(principal, properties);
    }

    public void SignOut()
    {
        ct.HttpContext!.SignOutAsync();
    }

    public string RandomPassword()
    {
        string s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string password = "";
        
        Random r = new();

        for (int i = 1; i <= 10; i++)
        {
            password += s[r.Next(s.Length)];
        }
       
        return password;
    }



    // ------------------------------------------------------------------------
    // Email Helper Functions
    // ------------------------------------------------------------------------

    public void SendEmail(MailMessage mail)
    {
        string user = cf["Smtp:User"] ?? "";
        string pass = cf["Smtp:Pass"] ?? "";
        string name = cf["Smtp:Name"] ?? "";
        string host = cf["Smtp:Host"] ?? "";
        int port = cf.GetValue<int>("Smtp:Port");

        mail.From = new MailAddress(user, name);

        using var smtp = new SmtpClient
        {
            Host = host,
            Port = port,
            EnableSsl = true,
            Credentials = new NetworkCredential(user, pass),
        };

        smtp.Send(mail);
    }

    // Demo SMS transport. Swap this implementation for a provider such as
    // Twilio/Messaging API in production; callers do not need to change.
    public bool SendSms(string telephone, string message)
    {
        if (string.IsNullOrWhiteSpace(telephone)) return false;

        var accountSid = cf["Twilio:AccountSid"];
        var authToken = cf["Twilio:AuthToken"];
        var fromNumber = cf["Twilio:FromNumber"];

        // Keep local demos usable without SMS credentials, while using Twilio
        // whenever the three local configuration values are present.
        if (string.IsNullOrWhiteSpace(accountSid) || string.IsNullOrWhiteSpace(authToken) || string.IsNullOrWhiteSpace(fromNumber))
        {
            Console.WriteLine($"[SMS demo to {telephone}] {message}");
            return true;
        }

        try
        {
            var client = hf.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(10);
            var credentials = Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($"{accountSid}:{authToken}"));
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["To"] = telephone,
                ["From"] = fromNumber,
                ["Body"] = message,
            });
            var response = client.PostAsync($"https://api.twilio.com/2010-04-01/Accounts/{accountSid}/Messages.json", content).GetAwaiter().GetResult();
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public string RecaptchaSiteKey => cf["Recaptcha:SiteKey"] ?? "";
    public bool IsRealSmsEnabled => !string.IsNullOrWhiteSpace(cf["Twilio:AccountSid"])
                                    && !string.IsNullOrWhiteSpace(cf["Twilio:AuthToken"])
                                    && !string.IsNullOrWhiteSpace(cf["Twilio:FromNumber"]);

    public string NormalizeTelephone(string? telephone)
    {
        var normalized = Regex.Replace(telephone ?? "", @"[\s\-()]", "");
        // Treat a Malaysian international number entered without its plus sign
        // as E.164, so Twilio receives +601... rather than 601....
        if (!normalized.StartsWith('+') && normalized.StartsWith("60")) normalized = "+" + normalized;
        return normalized;
    }

    // Verifies a Google reCAPTCHA v2 token against Google's siteverify endpoint.
    // Returns false (never throws) on any network/config failure, so a captcha
    // outage fails closed (blocks submission) rather than silently letting bots through.
    public bool VerifyRecaptcha(string? token)
    {
        if (string.IsNullOrWhiteSpace(token)) return false;

        // The Google test widget is enough for local development. Do not wait
        // on an external API call while students are running the project.
        if (en.IsDevelopment()) return true;

        try
        {
            string secret = cf["Recaptcha:SecretKey"] ?? "";
            var client = hf.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(5);

            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["secret"] = secret,
                ["response"] = token,
            });

            var response = client.PostAsync("https://www.google.com/recaptcha/api/siteverify", content)
                                  .GetAwaiter().GetResult();

            var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            using var doc = JsonDocument.Parse(json);

            return doc.RootElement.TryGetProperty("success", out var success)
                   && success.GetBoolean();
        }
        catch
        {
            return false;
        }
    }



    // ------------------------------------------------------------------------
    // DateTime Helper Functions
    // ------------------------------------------------------------------------

    // Return January (1) to December (12)
    public SelectList GetMonthList()
    {
        var list = new List<object>();

        for (int n = 1; n <= 12; n++)
        {
            list.Add(new
            {
                Id = n,
                Name = new DateTime(1, n, 1).ToString("MMMM"),
            });
        }

        return new SelectList(list, "Id", "Name");
    }

    // Return min to max years
    public SelectList GetYearList(int min, int max, bool reverse = false)
    {
        var list = new List<int>();

        for (int n = min; n <= max; n++)
        {
            list.Add(n);
        }

        if (reverse) list.Reverse();

        return new SelectList(list);
    }



    // ------------------------------------------------------------------------
    // Shopping Cart Helper Functions
    // ------------------------------------------------------------------------

    public Dictionary<string, int> GetCart()
    {
        return ct.HttpContext!.Session.Get<Dictionary<string, int>>("Cart") ?? [];
    }

    public void SetCart(Dictionary<string, int>? dict = null)
    {
        if (dict == null)
        {
            ct.HttpContext!.Session.Remove("Cart");
        }
        else
        {
            ct.HttpContext!.Session.Set("Cart", dict);
        }
    }
}
